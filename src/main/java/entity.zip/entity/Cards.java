package entity;

public class Cards {
	
	private String idnum;
	private String cardnum;
	private String expDate;
	private String cvv;
	
	public String getIdnum() {
		return idnum;
	}
	
	public void setIdnum(String idnum) {
		this.idnum = idnum;
	}
	
	public String getCardnum() {
		return cardnum;
	}
	
	public void setCardnum(String cardnum) {
		this.cardnum = cardnum;
	}
	
	public String getExpDate() {
		return expDate;
	}
	
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	
	public String getCvv() {
		return cvv;
	}
	
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	
}

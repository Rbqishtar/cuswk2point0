package entity;

public class SeatKinds {

    public static int BIG_SPACE = 4;
    public static int NEAR_EXIT = 6;

}

package entity;

public class Menu {
	
	private String type;
	private String dish;
	
	public String getType() {
		return type;
	}
	
	public void setType(String menutype) {
		this.type = menutype;
	}
	
	public String getDish() {
		return dish;
	}
	
	public void setDish(String menucontent) {
		this.dish = menucontent;
	}
	
}

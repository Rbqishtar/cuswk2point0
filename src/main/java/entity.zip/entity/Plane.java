package entity;

public class Plane {

	private String model;
	private int seatNum;
	private String size; // regular / wide 
	private String registerNo;
	
	public Plane(String model, int seatNum, String size, String registerNo) {
		super();
		this.model = model;
		this.seatNum = seatNum;
		this.size = size;
		this.registerNo = registerNo;
	}
	
	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	public int getSeatNum() {
		return seatNum;
	}
	
	public void setSeatNum(int seatNum) {
		this.seatNum = seatNum;
	}
	
	public String getSize() {
		return size;
	}
	
	public void setSize(String size) {
		this.size = size;
	}
	
	public String getRegisterNo() {
		return registerNo;
	}
	
	public void setRegisterNo(String registerNo) {
		this.registerNo = registerNo;
	}
	
}
